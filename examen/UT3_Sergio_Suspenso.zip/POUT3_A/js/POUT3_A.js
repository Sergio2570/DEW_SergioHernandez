const DOM = {
    tabla: document.querySelector("table"),
    cabeza: document.querySelector('thead'),
    cuerpo: document.querySelector('tbody'),
    pie: document.querySelector('tfoot')
};
const cabeza = DOM.cabeza;
const cuerpo = DOM.cuerpo;
function Ejecutar(){

}

function Colorear (){
    //no funca
    let fila = cabeza.querySelector("tr");
    fila.className = `cabecera`;
    let filas = cuerpo.querySelectorAll("tr");
    filas.forEach((tr,i) => { 
        let celda = filas[i].getElementsByTagName('td');
        if (i%2===0){
            celda[i].className = `columnaPar`;
        }
        else {
            celda[i].className = `columnaImpar`;
        }
            //td[i].classList.add(i%2===0?`columnaImpar` : `columnaPar`);
        });
/*
let filas = cuerpo.querySelectorAll("tr");
let celda = filas[0].getElementsByTagName('td');
*/
}

function BorrarOcho(){
    let filas = cuerpo.querySelectorAll("tr");
    filas.forEach((tr,i) => {
        if (filas[i].children.length == 9){
            filas[i].removeChild(filas[i].children[7]);
        }
    });
}


/*
.cabecera
.columnaPar
.columnaImpar
.primeraColumna
.pie
.borde_rojo
*/